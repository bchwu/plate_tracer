/*
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *<LicenseText>
 *
 * CitcomS by Louis Moresi, Shijie Zhong, Lijie Han, Eh Tan,
 * Clint Conrad, Michael Gurnis, and Eun-seo Choi.
 * Copyright (C) 1994-2005, California Institute of Technology.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *</LicenseText>
 *
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
#include <math.h>
#include <sys/types.h>
#include "element_definitions.h"
#include "global_defs.h"
#ifdef USE_GGRD
#include "ggrd_handling.h"
#endif

/*=======================================================================
  Calculate ages (MY) for opening input files -> material, ages, velocities
  Open these files, read in results, and average if necessary
=========================================================================*/

void full_read_input_files_for_timesteps(E,action,output)
    struct All_variables *E;
    int action, output;
{
    float find_age_in_MY();

    FILE *fp1, *fp2;
    float age, newage1, newage2;
    char output_file1[255],output_file2[255];
    /* 16-06-06 jshhuang*/
    char input_s[1000];
    /* end */
    float *TB1, *TB2, *VB1[4],*VB2[4], inputage1, inputage2;
    int nox,noz,noy,nnn,nox1,noz1,noy1;
    int i,ii,ll,m,mm,j,k,n,nodeg,nodel,node,cap;
    int intage, pos_age;
    int nodea;
    int nn,el;

    const int dims=E->mesh.nsd;

    int elx,ely,elz,elg,emax;
    float *VIP1,*VIP2;
    int *LL1, *LL2;

    int llayer;
    int layers();

    /* 16-06-06 jshhuang */
    int n1, n2, np, nd, l;
    float twopi, thirdpi, halfpi, degree2rad;
    float dx, dy, dd;
    const float dddd = E->viscosity.weak_bound_width / 2.0;
    const int npoint =  E->viscosity.weak_bound_xy_pointmax;
    /* end */

    /* 17-09-08 bchwu */
    static int fix_t1 = 0;
    static int fix_t2 = 0;
    /* end */

    /* 17-09-19 bchwu */
    int *iVB;
    char buffer[256];
    float fjunk0, fjunk1, fjunk2, fjunk3;
    /* end */
    
    nox=E->mesh.nox;
    noy=E->mesh.noy;
    noz=E->mesh.noz;
    nox1=E->lmesh.nox;
    noz1=E->lmesh.noz;
    noy1=E->lmesh.noy;

    elx=E->lmesh.elx;
    elz=E->lmesh.elz;
    ely=E->lmesh.ely;

    emax=E->mesh.elx*E->mesh.elz*E->mesh.ely;

    age=find_age_in_MY(E);

    if (age < 0.0) { /* age is negative -> use age=0 for input files */
      intage = 0;
      newage2 = newage1 = 0.0;
      pos_age = 0;
    }
    else {
      intage = age;
      newage1 = 1.0*intage;
      newage2 = 1.0*intage + 1.0;
      pos_age = 1;
    }

    for (m=1;m<=E->sphere.caps_per_proc;m++)  {
      cap = E->sphere.capid[m] - 1;  /* capid: 1-12 */

      switch (action) { /* set up files to open */

      case 1:  /* read velocity boundary conditions */
        if (fix_t1 == 1 && E->boundary.fix_init_age == 1)
            return;

        fix_t1 = 1;

#ifdef USE_GGRD
	if(!E->control.ggrd.vtop_control){
#endif
	sprintf(output_file1,"%s%0.0f.%d",E->control.velocity_boundary_file,newage1,cap);
	sprintf(output_file2,"%s%0.0f.%d",E->control.velocity_boundary_file,newage2,cap);
	fp1=fopen(output_file1,"r");
	if (fp1 == NULL) {
          fprintf(E->fp,"(Problem_related #4) Cannot open %s\n",output_file1);
          exit(8);
	}
	if (pos_age) {
	  fp2=fopen(output_file2,"r");
	  if (fp2 == NULL) {
	    fprintf(E->fp,"(Problem_related #5) Cannot open %s\n",output_file2);
	    exit(8);
	  }
	}
	if((E->parallel.me==0) && (output==1))   {
	  fprintf(E->fp,"Velocity: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
	  fprintf(E->fp,"Velocity: File1 = %s\n",output_file1);
	  if (pos_age)
	    fprintf(E->fp,"Velocity: File2 = %s\n",output_file2);
	  else
	    fprintf(E->fp,"Velocity: File2 = No file inputted (negative age)\n");
	}
#ifdef USE_GGRD
	}
#endif
	break;

      case 2:  /* read ages for lithosphere temperature assimilation */
#ifdef USE_GGRD
	if(!E->control.ggrd.age_control){
#endif
	sprintf(output_file1,"%s%0.0f.%d",E->control.lith_age_file,newage1,cap);
	sprintf(output_file2,"%s%0.0f.%d",E->control.lith_age_file,newage2,cap);
	fp1=fopen(output_file1,"r");
	if (fp1 == NULL) {
          fprintf(E->fp,"(Problem_related #6) Cannot open %s\n",output_file1);
          exit(8);
	}
	if (pos_age) {
	  fp2=fopen(output_file2,"r");
	  if (fp2 == NULL) {
	    fprintf(E->fp,"(Problem_related #7) Cannot open %s\n",output_file2);
	    exit(8);
	  }
	}
	if((E->parallel.me==0) && (output==1))   {
	  fprintf(E->fp,"Age: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
	  fprintf(E->fp,"Age: File1 = %s\n",output_file1);
	  if (pos_age)
	    fprintf(E->fp,"Age: File2 = %s\n",output_file2);
	  else
	    fprintf(E->fp,"Age: File2 = No file inputted (negative age)\n");
	}
#ifdef USE_GGRD
      }	
#endif
	break;

      case 3:  /* read element materials */
#ifdef USE_GGRD
	if(!E->control.ggrd.mat_control){
#endif
	sprintf(output_file1,"%s%0.0f.%d",E->control.mat_file,newage1,cap);
	sprintf(output_file2,"%s%0.0f.%d",E->control.mat_file,newage2,cap);
	fp1=fopen(output_file1,"r");
	if (fp1 == NULL) {
          fprintf(E->fp,"(Problem_related #8) Cannot open %s\n",output_file1);
          exit(8);
	}
	if (pos_age) {
	  fp2=fopen(output_file2,"r");
	  if (fp2 == NULL) {
	    fprintf(E->fp,"(Problem_related #9) Cannot open %s\n",output_file2);
	    exit(8);
	  }
	}
	if((E->parallel.me==0) && (output==1))   {
	  fprintf(E->fp,"Mat: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
	  fprintf(E->fp,"Mat: File1 = %s\n",output_file1);
	  if (pos_age)
	    fprintf(E->fp,"Mat: File2 = %s\n",output_file2);
	  else
	    fprintf(E->fp,"Mat: File2 = No file inputted (negative age)\n");
	}
#ifdef USE_GGRD
	}
#endif
	break;
	/* mode 4 is rayleigh control for GGRD, see below */

      case 5:  /* read temperature boundary conditions, top surface */
	sprintf(output_file1,"%s%0.0f.%d",E->control.temperature_boundary_file,newage1,cap);
	sprintf(output_file2,"%s%0.0f.%d",E->control.temperature_boundary_file,newage2,cap);
	fp1=fopen(output_file1,"r");
	if (fp1 == NULL) {
          fprintf(E->fp,"(Problem_related #10) Cannot open %s\n",output_file1);
          exit(8);
	}
	if (pos_age) {
	  fp2=fopen(output_file2,"r");
	  if (fp2 == NULL) {
	    fprintf(E->fp,"(Problem_related #11) Cannot open %s\n",output_file2);
	    exit(8);
	  }
	}
	if((E->parallel.me==0) && (output==1))   {
	  fprintf(E->fp,"Surface Temperature: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
	  fprintf(E->fp,"Surface Temperature: File1 = %s\n",output_file1);
	  if (pos_age)
	    fprintf(E->fp,"Surface Temperature: File2 = %s\n",output_file2);
	  else
	    fprintf(E->fp,"Velocity: File2 = No file inputted (negative age)\n");
	}
	break;
	
      /* 17-09-19 jshhuang */
      case 8:  /* read plate id */
        if (fix_t2 == 1 && E->boundary.fix_init_age == 1)
            return;

        fix_t2 = 1;

        sprintf(output_file1,"%s.%d_velocity_%0.2fMa.xy",E->viscosity.plate_id_filename, cap, newage1);
        fp1=fopen(output_file1,"r");
        if (fp1 == NULL) {
            fprintf(E->fp,"(Problem_related #case8_1) Cannot open %s\n",output_file1);
            exit(8);
        }
        
        if((E->parallel.me==0) && (output==1))   {
          fprintf(E->fp,"PlateId: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
          fprintf(E->fp,"PlateId: File = %s\n",output_file1);
          fprintf(E->fp, "newage1 = %.1f\n", newage1);
        }

 	/* plate id assignment */
        nnn=nox*noy;
        iVB=(int*) malloc ((nnn+1)*sizeof(int));
        for(i=1;i<=nnn;i++)   {
            fgets(buffer, 255, fp1);
            if (sscanf(buffer, "%f %f %f %f %d", &fjunk0, &fjunk1, &fjunk2, &fjunk3, &(iVB[i])) != 5) {
                fprintf(stderr, "Error while reading file '%s'\n", output_file1);
                exit(8);
            }
        }

        if(E->parallel.me_loc[3]==E->parallel.nprocz-1 )  {
            for(k=1;k<=noy1;k++)
                for(i=1;i<=nox1;i++)    {
                    nodeg = E->lmesh.nxs+i-1 + (E->lmesh.nys+k-2)*nox;
                    nodel = (k-1)*nox1 + i;
                    E->slice.surf_Pid[m][nodel] = iVB[nodeg];
                }
        }
	/* end */

        fclose(fp1);
        break;
	/* end of case 8 */

      /* 16-06-06 jshhuang */
      case 9:  /* read plate boundary points top surface */
        if (fix_t2 == 1 && E->boundary.fix_init_age == 1)
            return;

        fix_t2 = 1;

	sprintf(output_file1,"%s_%0.2fMa.xy",E->viscosity.weak_bound_filename,newage1);
        fp1=fopen(output_file1,"r");

        if (fp1 == NULL) {
          fprintf(E->fp,"(Problem_related #91) Cannot open %s\n",output_file1);
          exit(8);
        }

        if((E->parallel.me==0) && (output==1))   {
          fprintf(E->fp,"Weak boundary: Starting Age = %g, Elapsed time = %g, Current Age = %g\n",E->control.start_age,E->monitor.elapsed_time,age);
          fprintf(E->fp,"Plate boundary: File = %s\n",output_file1);
          fprintf(E->fp, "newage1 = %.1f\n", newage1);
        }

        for(i=1;i<=2;i++)  {
          VB1[i]=(float*) malloc ((npoint+1)*sizeof(float));
        }

        twopi = 2.*M_PI; thirdpi = 0.334*M_PI; halfpi = 0.5*M_PI; degree2rad = M_PI / 180.;
        dd = 0.0;

        // VB1[1]:longitude, VB1[2]:latitude
        for (l = 0; l <= npoint; l++) {
            VB1[1][l] = 0.0;
            VB1[2][l] = 0.0;
        }
        n1 = 0; n2 = 0; np = 0;

        for(i=1;i<=npoint;i++) {

          if(fgets(input_s,1000,fp1)==NULL)
            break;

          if(input_s[0] == '>') {/* begin of the data of one plate */

            if (n1 > 0) { // after first plate is read-in, interpolating...
              /* modified by Wu */
              np += 1; // first, add the first point
              E->viscosity.weak_bound_xy[1][np] = VB1[1][1];
              E->viscosity.weak_bound_xy[2][np] = VB1[2][1];

              /* modified by Wu: n2-1 */
              for (k = 1; k < n2-1; k++) { // loop the plate boundary points...
                if (VB1[1][k] > halfpi && VB1[1][k+1] < -halfpi && VB1[2][k] > thirdpi && VB1[2][k+1] < -thirdpi) { //1: up_right to down_left
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] + twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] + M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                     np += 1; // if close enough, add the next
                     E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                     E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1; // interpolating nd points
                    /* modified by Wu: l <= nd */
                    for (l = 1; l <= nd; l++) {
                      np += 1; // add inperpolating points one by one
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] + twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] + M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] > M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] - twopi;
                      if (E->viscosity.weak_bound_xy[2][np] > halfpi)
                         E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] - M_PI;
                    }
                  }
                } // end of 1.

                else if (VB1[1][k] > halfpi && VB1[1][k+1] < -halfpi && VB1[2][k] < -thirdpi && VB1[2][k+1] > thirdpi) { //2: down_right to up_left
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] + twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] - M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] + twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] - M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] > M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] - twopi;
                      if (E->viscosity.weak_bound_xy[2][np] < -halfpi)
                        E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] + M_PI;
                    }
                  }
                } // end of 2.

                else if (VB1[1][k] < -halfpi && VB1[1][k+1] > halfpi && VB1[2][k] > thirdpi && VB1[2][k+1] < -thirdpi) { // 3: up_left to down_right
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] - twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] + M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] - twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] + M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] < -M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] + twopi;
                      if (E->viscosity.weak_bound_xy[2][np] > halfpi)
                        E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] - M_PI;
                    }
                  }
                } // end of 3.

                else if (VB1[1][k] < -halfpi && VB1[1][k+1] > halfpi && VB1[2][k] < -thirdpi && VB1[2][k+1] > thirdpi) { // 4: down_left to up_right
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] - twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] - M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] - twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] - M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] < -M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] + twopi;
                      if (E->viscosity.weak_bound_xy[2][np] < -halfpi)
                        E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] + M_PI;
                    }
                  }
                } // end of 4.

                else if (VB1[2][k] > thirdpi && VB1[2][k+1] < -thirdpi) { //5: up to bottom
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k]);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] + M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k]) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] + M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[2][np] > halfpi)
                        E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] - M_PI;
                    }
                  }
                } // end of 5.

                else if (VB1[2][k] < -thirdpi && VB1[2][k+1] > thirdpi) { //6: bottom to up
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k]);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k] - M_PI);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k]) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k] - M_PI) * l / nd;
                      if (E->viscosity.weak_bound_xy[2][np] < -halfpi)
                        E->viscosity.weak_bound_xy[2][np] = E->viscosity.weak_bound_xy[2][np] + M_PI;
                    }
                  }
                } // end of 6.

                else if (VB1[1][k] > halfpi && VB1[1][k+1] < -halfpi) {// 7: right to left
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] + twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k]);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                     np += 1;
                     E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                     E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] + twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k]) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] > M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] - twopi;
                    }
                  }
                } // end of 7.

                else if (VB1[1][k] < -halfpi && VB1[1][k+1] > halfpi) { // 8: left to right
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k] - twopi);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k]);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k] - twopi) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k]) * l / nd;
                      if (E->viscosity.weak_bound_xy[1][np] < -M_PI)
                        E->viscosity.weak_bound_xy[1][np] = E->viscosity.weak_bound_xy[1][np] + twopi;
                    }
                  }
                } // end of 8.

                else { // 9: do not across boundaries
                  dx = 0.5 * (VB1[1][k+1] - VB1[1][k]);
                  dy = 0.5 * (VB1[2][k+1] - VB1[2][k]);
                  dd = 2.0 * sqrt(sin(dy)*sin(dy) + cos(VB1[2][k+1])*cos(VB1[2][k])*sin(dx)*sin(dx));

                  if (dd <= dddd || dd > dddd*200.) {
                    np += 1;
                    E->viscosity.weak_bound_xy[1][np] = VB1[1][k+1];
                    E->viscosity.weak_bound_xy[2][np] = VB1[2][k+1];
                  }
                  else {
                    nd = floor(dd/dddd) + 1;
                    for (l = 1; l <= nd; l++) {
                      np += 1;
                      E->viscosity.weak_bound_xy[1][np] = VB1[1][k] + (VB1[1][k+1] - VB1[1][k]) * l / nd;
                      E->viscosity.weak_bound_xy[2][np] = VB1[2][k] + (VB1[2][k+1] - VB1[2][k]) * l / nd;
                    }
                  }
                } // end of 9.
              } // end of for(k=1; k<n2; k++)
            } // end of if(n1>0)

            n1 = n1 + 1;
            n2 = 0;
            for (l = 0; l <= npoint; l++) {
              VB1[1][l] = 0.0;
              VB1[2][l] = 0.0;
            }

          } // end of if(input_s[0] == ">")
          else {
            n2 = n2 + 1;
            sscanf(input_s, "%g %g", &(VB1[1][n2]),&(VB1[2][n2]));

            VB1[1][n2] *= degree2rad;
            VB1[2][n2] *= degree2rad;

          }
        } // end of for(i=1;i<=npoint;i++)

        E->viscosity.weak_bound_xy_point = np;

        /* Test */
        if (E->parallel.me == 0)
          fprintf(stderr, "np = %d\n", np);

        for(i=1;i<=2;i++) {
          free ((void *) VB1[i]);
        }

        fclose(fp1);

        break;
        /* end of case 9 */

        } /* end switch */


      switch (action) { /* Read the contents of files and average */

      case 1:  /* velocity boundary conditions */
#ifdef USE_GGRD
	if(E->control.ggrd.vtop_control){
	  ggrd_read_vtop_from_file(E, 1);
	}else{
#endif
	nnn=nox*noy;
	for(i=1;i<=dims;i++)  {
	  VB1[i]=(float*) malloc ((nnn+1)*sizeof(float));
	  VB2[i]=(float*) malloc ((nnn+1)*sizeof(float));
	}
	for(i=1;i<=nnn;i++)   {
          if(fscanf(fp1,"%f %f",&(VB1[1][i]),&(VB1[2][i])) != 2) {
            fprintf(stderr,"Error while reading file '%s'\n",output_file1);
            exit(8);
          }
	  VB1[1][i] *= E->data.timedir;
	  VB1[2][i] *= E->data.timedir;
	  if (pos_age) {
            if(fscanf(fp2,"%f %f",&(VB2[1][i]),&(VB2[2][i])) != 2) {
              fprintf(stderr,"Error while reading file '%s'\n",output_file2);
              exit(8);
            }
	    VB2[1][i] *= E->data.timedir;
	    VB2[2][i] *= E->data.timedir;
	  }
	  /* if( E->parallel.me ==0)
	     fprintf(stderr,"%d %f  %f  %f  %f\n",i,VB1[1][i],VB1[2][i],VB2[1][i],VB2[2][i]); */
	}
	fclose(fp1);
	if (pos_age) fclose(fp2);

	if(E->parallel.me_loc[3]==E->parallel.nprocz-1 )  {
          for(k=1;k<=noy1;k++)
	    for(i=1;i<=nox1;i++)    {
	      nodeg = E->lmesh.nxs+i-1 + (E->lmesh.nys+k-2)*nox;
	      nodel = (k-1)*nox1*noz1 + (i-1)*noz1+noz1;
	      if (pos_age) { /* positive ages - we must interpolate */
		E->sphere.cap[m].VB[1][nodel] = (VB1[1][nodeg] + (VB2[1][nodeg]-VB1[1][nodeg])/(newage2-newage1)*(age-newage1))*E->data.scalev;
		E->sphere.cap[m].VB[2][nodel] = (VB1[2][nodeg] + (VB2[2][nodeg]-VB1[2][nodeg])/(newage2-newage1)*(age-newage1))*E->data.scalev;
		E->sphere.cap[m].VB[3][nodel] = 0.0;
	      }
	      else { /* negative ages - don't do the interpolation */
		E->sphere.cap[m].VB[1][nodel] = VB1[1][nodeg] * E->data.scalev;
		E->sphere.cap[m].VB[2][nodel] = VB1[2][nodeg] * E->data.scalev;
		E->sphere.cap[m].VB[3][nodel] = 0.0;
	      }
	    }
	}   /* end of E->parallel.me_loc[3]==E->parallel.nproczl-1   */
	for(i=1;i<=dims;i++) {
          free ((void *) VB1[i]);
          free ((void *) VB2[i]);
	}
#ifdef USE_GGRD
	}
#endif
	break;

      case 2:  /* ages for lithosphere temperature assimilation */
#ifdef USE_GGRD
	if(E->control.ggrd.age_control){
	  ggrd_read_age_from_file(E, 1);
	}else{
#endif
	for(i=1;i<=noy;i++)
	  for(j=1;j<=nox;j++) {
	    node=j+(i-1)*nox;
	    if(fscanf(fp1,"%f",&inputage1) != 1) {
              fprintf(stderr,"Error while reading file '%s'\n",output_file1);
              exit(8);
            }
	    if (pos_age) { /* positive ages - we must interpolate */
              if(fscanf(fp2,"%f",&inputage2) != 1) {
                fprintf(stderr,"Error while reading file '%s'\n",output_file2);
                exit(8);
              }
              E->age_t[node] = (inputage1 + (inputage2-inputage1)/(newage2-newage1)*(age-newage1))/E->data.scalet;
	    }
	    else { /* negative ages - don't do the interpolation */
              E->age_t[node] = inputage1;
	    }
	  }
	fclose(fp1);
	if (pos_age) fclose(fp2);
#ifdef USE_GGRD
	} /* end of branch if allowing for ggrd handling */
#endif
	break;

      case 3:  /* read element materials and Ray */
#ifdef USE_GGRD
	if(E->control.ggrd.mat_control){ /* use netcdf grids */
	  ggrd_read_mat_from_file(E, 1);
	}else{
#endif
        VIP1 = (float*) malloc ((emax+1)*sizeof(float));
        VIP2 = (float*) malloc ((emax+1)*sizeof(float));
        LL1 = (int*) malloc ((emax+1)*sizeof(int));
        LL2 = (int*) malloc ((emax+1)*sizeof(int));


        for(m=1;m<=E->sphere.caps_per_proc;m++)
          for (el=1; el<=elx*ely*elz; el++)  {
            nodea = E->ien[m][el].node[2];
            llayer = layers(E,m,nodea);
            if (llayer)  { /* for layers:1-lithosphere,2-upper, 3-trans, and 4-lower mantle */
              E->mat[m][el] = llayer;
              fprintf(stderr,"\nINSIDE llayer=%d",llayer);
            }
          }
          for(i=1;i<=emax;i++)  {
            if(fscanf(fp1,"%d %d %f", &nn,&(LL1[i]),&(VIP1[i])) != 3) {
              fprintf(stderr,"Error while reading file '%s'\n",output_file1);
              exit(8);
            }
            if(fscanf(fp2,"%d %d %f", &nn,&(LL2[i]),&(VIP2[i])) != 3) {
              fprintf(stderr,"Error while reading file '%s'\n",output_file2);
              exit(8);
            }
          }

          fclose(fp1);
          fclose(fp2);

          for (m=1;m<=E->sphere.caps_per_proc;m++) {
            for (k=1;k<=ely;k++)   {
              for (i=1;i<=elx;i++)   {
                for (j=1;j<=elz;j++)  {
                  el = j + (i-1)*E->lmesh.elz + (k-1)*E->lmesh.elz*E->lmesh.elx;
                  elg = E->lmesh.ezs+j + (E->lmesh.exs+i-1)*E->mesh.elz + (E->lmesh.eys+k-1)*E->mesh.elz*E->mesh.elx;

                  E->VIP[m][el] = VIP1[elg]+(VIP2[elg]-VIP1[elg])/(newage2-newage1)*(age-newage1);
                  /* E->mat[m][el] = LL1[elg]; */ /*get material numbers from radius internally */

                }     /* end for j  */
              }     /*  end for i */
            }     /*  end for k  */
          }     /*  end for m  */

         free ((void *) VIP1);
         free ((void *) VIP2);
         free ((void *) LL1);
         free ((void *) LL2);
#ifdef USE_GGRD
	} /* end of branch if allowing for ggrd handling */
#endif
	break;
      case 4:			/* material control */
#ifdef USE_GGRD
	/* read laterally varying rayleigh number prefactor from
	   file */
	if(E->control.ggrd.ray_control)
	  ggrd_read_ray_from_file(E, 1);
#else
	myerror(E,"input_from_files: mode 4 only for GGRD");
#endif
      break;

      case 5:  /* read temperature boundary conditions, top surface */
	nnn=nox*noy;
	TB1=(float*) malloc ((nnn+1)*sizeof(float));
	TB2=(float*) malloc ((nnn+1)*sizeof(float));

	for(i=1;i<=nnn;i++)   {
          if(fscanf(fp1,"%f",&(TB1[i])) != 1) {
            fprintf(stderr,"Error while reading file '%s'\n",output_file1);
            exit(8);
          }
	  if (pos_age) {
            if(fscanf(fp2,"%f",&(TB2[i])) != 1) {
              fprintf(stderr,"Error while reading file '%s'\n",output_file2);
              exit(8);
            }
	  }
        }
	fclose(fp1);
	if (pos_age) fclose(fp2);

	if(E->parallel.me_loc[3]==E->parallel.nprocz-1 )  {
          for(k=1;k<=noy1;k++)
	    for(i=1;i<=nox1;i++)    {
	      nodeg = E->lmesh.nxs+i-1 + (E->lmesh.nys+k-2)*nox;
	      nodel = (k-1)*nox1*noz1 + (i-1)*noz1+noz1;
	      if (pos_age) { /* positive ages - we must interpolate */
		E->sphere.cap[m].TB[1][nodel] = (TB1[nodeg] + (TB2[nodeg]-TB1[nodeg])/(newage2-newage1)*(age-newage1));
		E->sphere.cap[m].TB[2][nodel] = (TB1[nodeg] + (TB2[nodeg]-TB1[nodeg])/(newage2-newage1)*(age-newage1));
		E->sphere.cap[m].TB[3][nodel] = (TB1[nodeg] + (TB2[nodeg]-TB1[nodeg])/(newage2-newage1)*(age-newage1));
	      }
	      else { /* negative ages - don't do the interpolation */
		E->sphere.cap[m].TB[1][nodel] = TB1[nodeg];
		E->sphere.cap[m].TB[2][nodel] = TB1[nodeg];
		E->sphere.cap[m].TB[3][nodel] = TB1[nodeg];
	      }
	    }
	}   /* end of E->parallel.me_loc[3]==E->parallel.nproczl-1   */
        free ((void *) TB1);
        free ((void *) TB2);
	break;

      } /* end switch */
    } /* end for m */

    fflush(E->fp);

    return;
}
